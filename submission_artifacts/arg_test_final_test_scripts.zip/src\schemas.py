﻿from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class TestCase:
    test_id: str
    technique: str
    requirement_target: str
    preconditions: str
    input_data: str
    expected_output: str
    covered_item: str
    priority: str = "Medium"
    checker_status: str = "pending"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["input"] = payload.pop("input_data")
        return payload

    def normalized_signature(self) -> str:
        return " | ".join(
            [
                self.technique.strip().lower(),
                self.requirement_target.strip().lower(),
                self.input_data.strip().lower(),
                self.expected_output.strip().lower(),
            ]
        )


@dataclass
class RiskAssessment:
    level: str
    score: float
    rule_count: int
    numeric_constraint_count: int
    technique_count: int
    drivers: list[str] = field(default_factory=list)
    recommended_focus: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["score"] = round(float(self.score), 3)
        return payload


@dataclass
class StateTransition:
    source_state: str
    trigger: str
    target_state: str
    legal: bool = True
    source_rule: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def signature(self) -> str:
        arrow = "->" if self.legal else "-x>"
        return f"{self.source_state} {arrow} {self.target_state} [{self.trigger}]"


@dataclass
class StateTestSequence:
    sequence_id: str
    coverage_goal: str
    steps: list[str]
    covered_states: list[str]
    covered_transitions: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StateCoveragePlan:
    coverage_goal: str
    sequence_count: int
    fully_covered: bool
    sequences: list[StateTestSequence] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "coverage_goal": self.coverage_goal,
            "sequence_count": self.sequence_count,
            "fully_covered": self.fully_covered,
            "sequences": [sequence.to_dict() for sequence in self.sequences],
        }


@dataclass
class StateModel:
    states: list[str]
    start_states: list[str]
    legal_transitions: list[StateTransition] = field(default_factory=list)
    illegal_transitions: list[StateTransition] = field(default_factory=list)
    coverage_plans: list[StateCoveragePlan] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "states": self.states,
            "start_states": self.start_states,
            "legal_transitions": [transition.to_dict() for transition in self.legal_transitions],
            "illegal_transitions": [transition.to_dict() for transition in self.illegal_transitions],
            "coverage_plans": [plan.to_dict() for plan in self.coverage_plans],
            "notes": self.notes,
        }

    def to_markdown(self, requirement_id: str) -> str:
        lines = [
            f"# State Model: {requirement_id}",
            "",
            f"- States: `{', '.join(self.states)}`" if self.states else "- States: `none`",
            f"- Start states: `{', '.join(self.start_states)}`" if self.start_states else "- Start states: `none`",
            "",
            "## Legal Transitions",
            "",
            "| Source | Trigger | Target | Rule |",
            "| --- | --- | --- | --- |",
        ]
        if self.legal_transitions:
            for transition in self.legal_transitions:
                lines.append(
                    f"| {transition.source_state} | {transition.trigger} | {transition.target_state} | {transition.source_rule or ''} |"
                )
        else:
            lines.append("|  |  |  |  |")

        lines.extend(
            [
                "",
                "## Illegal Transitions",
                "",
                "| Source | Trigger | Target | Rule |",
                "| --- | --- | --- | --- |",
            ]
        )
        if self.illegal_transitions:
            for transition in self.illegal_transitions:
                lines.append(
                    f"| {transition.source_state} | {transition.trigger} | {transition.target_state} | {transition.source_rule or ''} |"
                )
        else:
            lines.append("|  |  |  |  |")

        for plan in self.coverage_plans:
            lines.extend(
                [
                    "",
                    f"## Coverage Plan: {plan.coverage_goal}",
                    "",
                    f"- Sequence count: `{plan.sequence_count}`",
                    f"- Fully covered: `{str(plan.fully_covered).lower()}`",
                    "",
                ]
            )
            for sequence in plan.sequences:
                lines.append(f"### {sequence.sequence_id}")
                lines.append("")
                lines.append(f"- Covered states: `{', '.join(sequence.covered_states)}`")
                if sequence.covered_transitions:
                    lines.append(f"- Covered transitions: `{'; '.join(sequence.covered_transitions)}`")
                lines.append("")
                for step in sequence.steps:
                    lines.append(f"- {step}")
                lines.append("")

        if self.notes:
            lines.extend(["## Notes", ""])
            lines.extend(f"- {note}" for note in self.notes)
            lines.append("")
        return "\n".join(lines).strip() + "\n"


@dataclass
class ParsedTrace:
    requirement_id: str
    analysis: str
    pattern: str
    steps: list[str]
    verification: str
    test_cases: list[TestCase]
    raw_text: str
    category: str | None = None
    risk_assessment: RiskAssessment | None = None
    state_model: StateModel | None = None
    missing_sections: list[str] = field(default_factory=list)

    def selected_techniques(self) -> list[str]:
        techniques: list[str] = []
        lowered = self.pattern.lower()
        mapping = {
            "EP": ["ep", "equivalence partition"],
            "BVA": ["bva", "boundary value"],
            "Decision Table": ["decision table"],
            "State Transition": ["state transition"],
        }
        for label, aliases in mapping.items():
            if any(alias in lowered for alias in aliases):
                techniques.append(label)
        return techniques

    def to_dict(self) -> dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "category": self.category,
            "risk_assessment": self.risk_assessment.to_dict() if self.risk_assessment else None,
            "state_model": self.state_model.to_dict() if self.state_model else None,
            "analysis": self.analysis,
            "pattern": self.pattern,
            "steps": self.steps,
            "verification": self.verification,
            "missing_sections": self.missing_sections,
            "test_cases": [case.to_dict() for case in self.test_cases],
        }

    def to_markdown(self) -> str:
        lines = [
            "Analysis:",
            self.analysis.strip(),
            "",
            "Pattern:",
            self.pattern.strip(),
            "",
            "Steps:",
        ]
        if self.steps:
            lines.extend(self.steps)
        else:
            lines.append("1. No steps were captured.")
        lines.extend(["", "Verification:", self.verification.strip(), "", "FinalAnswer:"])
        lines.extend(
            [
                "| Test ID | Technique | Requirement Target | Preconditions | Input | Expected Output | Covered Item | Priority | Checker Status |",
                "| --- | --- | --- | --- | --- | --- | --- | --- | --- |",
            ]
        )
        for case in self.test_cases:
            row = [
                case.test_id,
                case.technique,
                case.requirement_target,
                case.preconditions,
                case.input_data,
                case.expected_output,
                case.covered_item,
                case.priority,
                case.checker_status,
            ]
            lines.append("| " + " | ".join(cell.replace("|", "/") for cell in row) + " |")
        return "\n".join(lines).strip() + "\n"


@dataclass
class CheckResult:
    name: str
    passed: bool
    score: float
    diagnostics: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CandidateEvaluation:
    requirement_id: str
    requirement_text: str
    raw_text: str
    parsed_trace: ParsedTrace
    checks: list[CheckResult]
    score: float
    repaired: bool = False
    source: str = "structured"
    candidate_index: int | None = None
    generation_metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "requirement_text": self.requirement_text,
            "score": self.score,
            "repaired": self.repaired,
            "source": self.source,
            "candidate_index": self.candidate_index,
            "generation_metadata": self.generation_metadata,
            "checks": [check.to_dict() for check in self.checks],
            "parsed_trace": self.parsed_trace.to_dict(),
        }

    def diagnostics(self) -> list[str]:
        details: list[str] = []
        for check in self.checks:
            details.extend([f"{check.name}: {item}" for item in check.diagnostics])
        return details
